#include <stdio.h>
#include <stdlib.h>

typedef struct{
char nombre[20];
int edad;
}ePersona;

int main()
{
    ePersona gente[]= {{"Juan", 30}, {"Ana", 24}, {"Jose", 28}};

    int cantidad;
    FILE* f;
    f = fopen("arrayPersonas.bin", "wb");

    if(f ==NULL){
        exit(1);
    }

    cantidad = fwrite(gente, sizeof(ePersona), 3, f);

    if(cantidad < 1){
        printf("Problemas al escribir el archivo");
    }
    else{
        printf("Array guardado en el archivo");
    }

    fclose(f);



    return 0;
}
