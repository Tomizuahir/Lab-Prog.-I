#include <stdio.h>
#include <stdlib.h>

typedef struct{
char nombre[20];
int edad;
}ePersona;

int main()
{
    ePersona lista[3];

   FILE* f;
    f = fopen("arrayPersonas.bin", "rb");

    if(f ==NULL){

            printf("Hubo un problema al intentar abtir el fichero");
        exit(1);
    }

    fread(lista, sizeof(ePersona), 3, f);

    fclose(f);


for(int i=0; i <3; i++){
     printf("Nombre: %s Edad: %d\n\n", lista[i].nombre, lista[i].edad);
}
printf("\n\n");

    return 0;
}
