#include <stdio.h>
#include <stdlib.h>

typedef struct{
char nombre[20];
int edad;
}ePersona;

int main()
{
    ePersona unaPersona;
    ePersona otraPersona;

    int cantidad;

    strcpy(unaPersona.nombre, "Jose");
    unaPersona.edad = 30;

    FILE* f;
    f = fopen("personas.bin", "wb");

    if(f ==NULL){
        exit(1);
    }

    cantidad = fwrite(&unaPersona, sizeof(ePersona), 1, f);

    if(cantidad < 1){
        printf("Problemas al escribir el archivo");
    }

    fclose(f);


    f = fopen("persona.bin", "rb");

    if(f ==NULL){

            printf("Hubo un problema al intentar abtir el fichero");
        exit(1);
    }

    fread(&otraPersona, sizeof(ePersona), 1, f);

    fclose(f);




    printf("Nombre: %s Edad: %d\n\n", otraPersona.nombre, otraPersona.edad);
    return 0;
}
