#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

    int tam = 0;
    int i;
    int cant;
    char aux;
    char* vec;
    char* vecaux;

    FILE* f;

    f = fopen("Prueba.txt", "r");
        if(f == NULL){
        exit(1);
    }

    cant = fread(&aux, sizeof(char), 1, f);

    if(cant == 1){

            vec = (char*) malloc(sizeof(char));
            tam++;

            *vec = aux;
    }

    while(!feof(f)){

        cant = fread(&aux, sizeof(char), 1, f);

         if(cant == 1){


            vecaux = (char*) realloc(vec, sizeof(char)* (tam +1));
            if(vecaux != NULL){
                vec = vecaux;

            }

            *(vec + tam) = aux;
            tam = tam +1;
    }

    }


    fclose(f);

    for(i=0; i < tam; i++ ){
        printf("%c", *(vec + i));
    }


    printf("\n\n");
    return 0;
}
