#include <stdio.h>
#include <stdlib.h>

int main()
{
    char auxCad[70];
    FILE* f;
    f = fopen("pagina.html", "w");
    if(f ==NULL){
        exit(1);
    }
    movies
    fprintf(f, "<html><head><title>Pagina de peliculas</title></head><body><table>");
    for(int i; i< tam; i++){
        fprintf(f, "<tr><td> %d </td><td> %s </td><td> %d</td></tr>", movies[i].id, movies[i].titulo, movies[i].duracion);

    }
    fprintf(f, "</table></body></html>");

    fprintf(f, "");
    fclose(f);

    f = fopen("prueba.txt", "r");
    if(f ==NULL){
        exit(1);
    }

    while(!feof(f)){

        fread(auxCad, sizeof(char), 70,f);
        printf("%s", auxCad);
    }

    fclose(f);




    return 0;
}


