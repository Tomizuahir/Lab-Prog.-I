#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char nombre[20];
    int legajo;
    float sueldo;

} eEmpleado;

void mostrarEmpleado(eEmpleado*);

eEmpleado* new_Empleado();
eEmpleado* new_EmpleadoParam(char*, int, float);

int main()
{
    eEmpleado* lista[5];

    eEmpleado* unEmpleado;
    eEmpleado* otroEmpleado;
    eEmpleado* otroEmpleadoMas;

    char nombre[20];
    int legajo;
    float sueldo;

    unEmpleado = new_Empleado();

    otroEmpleado = new_EmpleadoParam("Juan", 222, 25000);

    mostrarEmpleado(unEmpleado);

    mostrarEmpleado(otroEmpleado);


     printf("Ingrese nombre: ");
     gets(nombre);

     printf("Ingrese legajo: ");
     scanf("%d", &legajo);

     printf("Ingrese sueldo: ");
     scanf("%f", &sueldo);

     //otroEmpleadoMas = new_EmpleadoParam(nombre, legajo, sueldo);



     mostrarEmpleado(otroEmpleadoMas);



    return 0;
}

void mostrarEmpleado(eEmpleado* x)
{

    printf("Nombre: %s  Legajo: %d  Sueldo: %.2f\n\n", x->nombre, x->legajo, x->sueldo);
}


eEmpleado* new_Empleado()
{

    eEmpleado* x;

    x = (eEmpleado*) malloc(sizeof(eEmpleado));

    if(x !=NULL)
    {
        strcpy(x->nombre, "");
        x->legajo = 0;
        x->sueldo =0;
    }
    return x;
}

eEmpleado* new_EmpleadoParam(char* nombre, int legajo, float sueldo)
{

    eEmpleado* x;

    x = new_Empleado();

    if(x !=NULL)
    {
        strcpy(x->nombre, nombre);
        x->legajo = legajo;
        x->sueldo = sueldo;
    }
    return x;




}
