#include <stdio.h>
#include <stdlib.h>
#include <string.h>



typedef struct{
    char nombre[20];
    int idCat;
}eProgramador;

typedef struct{
    int id;
    char descCategoria[20];
}eCategoria;

void mostrarProgramador(eProgramador, eCategoria[], int);

int main()
{

    eCategoria categorias[] = {{1, "junior"}, {2, "SemiSenior"}, {3, "Senior"}};
    eProgramador unProgramador = {"Juan", 3};


        mostrarProgramador(unProgramador, categorias, 3);


    return 0;
}

void mostrarProgramador(eProgramador x, eCategoria arrayCat[], int tamCat){

    char cat[20];
    for(int i = 0; i < tamCat; i++){

        if( x.idCat == arrayCat[i].id)
        {
            strcpy(cat, arrayCat[i].descCategoria);
            break;
        }
    }

    printf("\n%s %s\n\n", x.nombre, cat);

}
